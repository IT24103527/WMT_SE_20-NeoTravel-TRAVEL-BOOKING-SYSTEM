// src/config/seedAdmin.js
const User = require('../models/User');
const bcrypt = require('bcryptjs');

const seedAdmin = async () => {
  try {
    const adminEmail = 'admin@gmail.com';

    const existing = await User.findOne({ email: adminEmail });

    if (existing) {
      console.log('Admin already exists');
      return;
    }

    const hashedPassword = await bcrypt.hash('admin123', 10);

    await User.create({
      name: 'Admin',
      email: adminEmail,
      password: hashedPassword,
      role: 'admin'
    });

    console.log('Admin created: admin@gmail.com / admin123');
  } catch (err) {
    console.error('Admin seed error', err);
  }
};

module.exports = seedAdmin;