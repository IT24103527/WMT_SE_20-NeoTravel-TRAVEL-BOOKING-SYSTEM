// src/controllers/booking.controller.js
const Booking = require('../models/Booking');

// Create booking (user)
exports.createBooking = async (req, res) => {
  const booking = await Booking.create({
    user: req.user._id,
    package: req.body.packageId,
    date: req.body.date
  });

  res.status(201).json(booking);
};

// Get my bookings
exports.getMyBookings = async (req, res) => {
  const bookings = await Booking.find({ user: req.user._id })
    .populate('package');

  res.json(bookings);
};

// Admin: all bookings
exports.getAllBookings = async (req, res) => {
  const bookings = await Booking.find()
    .populate('user')
    .populate('package');

  res.json(bookings);
};