// src/pages/Bookings.jsx
import { useEffect, useState } from 'react';
import axios from 'axios';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Bookings() {
  const [bookings, setBookings] = useState([]);

  const fetchBookings = async () => {
    const res = await axios.get('/api/v1/bookings/me', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setBookings(res.data);
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  return (
    <View>
      <Text>My Bookings</Text>

      {bookings.map(b => (
        <View key={b._id}>
          <Text>{b.package.title}</Text>
          <Text>{new Date(b.date).toDateString()}</Text>
        </View>
      ))}
    </View>
  );
}