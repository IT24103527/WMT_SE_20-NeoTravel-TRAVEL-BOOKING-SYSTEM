// src/pages/Packages.jsx
import { useEffect, useState } from 'react';
import axios from 'axios';
import useAuth from '../../hooks/useAuth';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Packages() {
  const [packages, setPackages] = useState([]);
  const { user: authUser } = useAuth();

  const role = authUser?.role; // ✅ safe

  const fetchPackages = async () => {
    const res = await axios.get('/api/v1/packages');
    setPackages(res.data);
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  const deletePackage = async (id) => {
    await axios.delete(`/api/v1/packages/${id}`, {
      headers: { Authorization: `Bearer ${authUser?.token}` }
    });
    fetchPackages();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Packages</Text>

      {role === 'admin' && (
        <Button
          title="+ Add Package"
          onPress={() => alert('Open create form')}
        />
      )}

      {packages.map(pkg => (
        <View key={pkg._id} style={styles.card}>
          <Text>{pkg.title}</Text>
          <Text>{pkg.description}</Text>
          <Text>${pkg.price}</Text>

          {role === 'admin' && (
            <>
              <Button title="Edit" onPress={() => {}} />
              <Button
                title="Delete"
                onPress={() => deletePackage(pkg._id)}
              />
            </>
          )}

          {role === 'user' && (
            <Button title="Book" onPress={() => {}} />
          )}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold' },
  card: { marginTop: 10, padding: 10, backgroundColor: '#eee' }
});