import { View, Text, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import useAuth from '../../hooks/useAuth';

export default function BottomNav() {
  const navigation = useNavigation();
  const { user } = useAuth();

  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-around', padding: 15 }}>

      <TouchableOpacity onPress={() => navigation.navigate("Packages")}>
        <Text>Packages</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Bookings")}>
        <Text>Bookings</Text>
      </TouchableOpacity>

      {user?.role === "admin" && (
        <TouchableOpacity onPress={() => navigation.navigate("AdminPackages")}>
          <Text>Admin</Text>
        </TouchableOpacity>
      )}

      <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
        <Text>Profile</Text>
      </TouchableOpacity>

    </View>
  );
}